<?php
/**
 * Plugin Name: AIO Google Drive Extension
 * Plugin URI: https://youtube.com/@adnanhabib
 * Description: Google Drive Extension For AIO Migraion
 * Author: Adnan Habib
 * Author URI: https://youtube.com/@adnanhabib
 * Version: 2.47
 * Text Domain: all-in-one-wp-migration-gdrive-extension
 * Domain Path: /languages
 * Network: True
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Kangaroos cannot jump here' );
}

// Check SSL Mode
if ( isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && ( $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https' ) ) {
	$_SERVER['HTTPS'] = 'on';
}

// Plugin Basename
define( 'AI1WMGE_PLUGIN_BASENAME', basename( dirname( __FILE__ ) ) . '/' . basename( __FILE__ ) );

// Plugin Path
define( 'AI1WMGE_PATH', dirname( __FILE__ ) );

// Plugin URL
define( 'AI1WMGE_URL', plugins_url( '', AI1WMGE_PLUGIN_BASENAME ) );

// Include constants
require_once dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'constants.php';

// Include exceptions
require_once dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'exceptions.php';

// Include loader
require_once dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'loader.php';

// ===========================================================================
// = All app initialization is done in Ai1wmge_Main_Controller __constructor =
// ===========================================================================
$main_controller = new Ai1wmge_Main_Controller();
